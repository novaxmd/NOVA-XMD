import fetch from 'node-fetch';
import { sendInteractive } from '../../lib/sendInteractive.js';
  const NEXRAY = 'https://api.nexray.web.id/downloader/twitter?url=';

  export default async (context) => {
      const { client, m, text, prefix } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
      if (!text) {
          await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
          return sendInteractive(client, m, `│ Example: ${prefix}twitter https://x.com/user/status/xxxx\n╰───────────────\n> ©BMB TECH`);
      }
      if (!text.includes('twitter.com') && !text.includes('x.com') && !text.includes('t.co')) return sendInteractive(client, m, '│ That\'s not a Twitter/X link.\n╰───────────────\n> ©BMB TECH');
      await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
      try {
          const r = await fetch(NEXRAY + encodeURIComponent(text.trim()), { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000 });
          const d = await r.json();
          if (!d.status || !d.result) throw new Error('API failed');
          const { title, duration, download_url } = d.result;
          const best = (download_url || []).find(u => u.type === 'mp4') || (download_url || [])[0];
          if (!best?.url) throw new Error('No video found in this tweet');
          const dlRes = await fetch(best.url, { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 40000 });
          if (!dlRes.ok) throw new Error('Download failed: ' + dlRes.status);
          const buf = Buffer.from(await dlRes.arrayBuffer());
          await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
          await client.sendMessage(m.chat, {
              video: buf, mimetype: 'video/mp4',
              caption: `🎬 *TWITTER/X VIDEO*\n━━━━━━━━━━━━━━━━\n${(title || '').slice(0, 80)}\nDuration: ${duration || 'N/A'}\nQuality: ${best.resolusi || 'HD'}\n━━━━━━━━━━━━━━━━\n© bmb tech`
          });
      } catch (e) {
          await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } });
          sendInteractive(client, m, `│ Twitter/X download failed.\n│ The tweet might be private or deleted.\n│ Try again later.\n╰───────────────\n> ©BMB TECH`);
      }
  };
  